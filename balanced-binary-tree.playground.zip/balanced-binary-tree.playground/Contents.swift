// Definition for a binary tree node.
public class TreeNode {
    public var val: Int
    public var left: TreeNode?
    public var right: TreeNode?
    public init() { self.val = 0; self.left = nil; self.right = nil; }
    public init(_ val: Int) { self.val = val; self.left = nil; self.right = nil; }
    public init(_ val: Int, _ left: TreeNode?, _ right: TreeNode?) {
        self.val = val
        self.left = left
        self.right = right
    }
}

class Solution {
    // 定义一个函数来构造二叉树
        func buildTree(_ values: [Int?]) -> TreeNode? {
            // 如果输入数组为空，则返回空指针
            if values.isEmpty {
                return nil
            }

            // 使用队列来存储节点
            var queue = [TreeNode]()
            let root = TreeNode(values[0]!)
            queue.append(root)
            var index = 1

            while !queue.isEmpty && index < values.count {
                let node = queue.removeFirst()

                if let left = values[index] {
                    node.left = TreeNode(left)
                    queue.append(node.left!)
                }
                index += 1

                if index < values.count, let right = values[index] {
                    node.right = TreeNode(right)
                    queue.append(node.right!)
                }
                index += 1
            }

            return root
        }

    func isBalanced(_ root: TreeNode?) -> Bool {
        // 定义一个辅助函数来计算二叉树的高度
        func getHeight(_ root: TreeNode?) -> Int {
            // 如果二叉树为空，则返回0
            if root == nil {
                return 0
            }
            // 递归地计算左子树的高度
            let leftHeight = getHeight(root!.left)
            // 如果左子树不是高度平衡的，则直接返回-1
            if leftHeight == -1 {
                return -1
            }
            // 递归地计算右子树的高度
            let rightHeight = getHeight(root!.right)
            // 如果右子树不是高度平衡的，则直接返回-1
            if rightHeight == -1 {
                return -1
            }
            // 如果左右子树的高度差大于1，则返回-1
            if abs(leftHeight - rightHeight) > 1 {
                return -1
            }
            // 否则返回二叉树的高度
            return max(leftHeight, rightHeight) + 1
        }

        return getHeight(root) != -1
    }
}


let solution = Solution()
let root = solution.buildTree([1,2,2,3,3,nil,nil,4,4])
let isBalanced = solution.isBalanced(root)
print(isBalanced)  // 输出 True
